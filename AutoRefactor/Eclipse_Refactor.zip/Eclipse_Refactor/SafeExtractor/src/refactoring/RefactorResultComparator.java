package refactoring;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

// 和你当前JSON结构对齐
class RefactorRecord {
	public String className;
	public String exprText;
	public int extractLength;
	public int extractOffset;
	public String message;
	public String methodName;
	public String newVariableName;
	public String oldVariableName;
	public String packageName;
	public String sourceFilePath;
	public boolean success;
}

// 一对Eclipse、IDEA的匹配记录
class RefactorPair {
	public RefactorRecord eclipseRec;
	public RefactorRecord ideaRec;
	public String eclipseFileFullPath;
	public String ideaFileFullPath;

	public RefactorPair(RefactorRecord e, RefactorRecord i, String ePath, String iPath) {
		this.eclipseRec = e;
		this.ideaRec = i;
		this.eclipseFileFullPath = ePath;
		this.ideaFileFullPath = iPath;
	}
}

// 分类结果【重点：字段名称严格一致】
class CompareResult {
	// 1. 文件读取异常候选（后续再用javac判断编译错误）
	public List<RefactorPair> compileErrorCandidateList = new ArrayList<>();
	// 2. 重构执行不一致：success一true一false
	public List<RefactorPair> inconsistentSuccessList = new ArrayList<>();
	// 3. 两边都成功重构，但磁盘源码文本不同
	public List<RefactorPair> successButCodeDiffList = new ArrayList<>();
}

public class RefactorResultComparator {
	private static final Gson gson = new Gson();

	// ========== 这里修改为你本地路径 ==========
	private static final String ECLIPSE_PROJECT_ROOT = "D:/runtime-EclipseApplication/TEST";
	private static final String IDEA_PROJECT_ROOT = "D:/IDEA/TEST";

	private static String buildKey(RefactorRecord r) {
		return r.packageName + "|" + r.className + "|" + r.sourceFilePath;
	}

	private static String getLocalFilePath(String projectRoot, String sourceFilePath) {
		String relative = sourceFilePath.replaceFirst("^/TEST", "");
		return new File(projectRoot, relative).getAbsolutePath();
	}

	private static String readFileText(String fullPath) throws IOException {
		File f = new File(fullPath);
		if (!f.exists()) {
			return null;
		}
		return Files.readString(f.toPath(), StandardCharsets.UTF_8);
	}

	// 消除空格换行差异
	private static String normalizeCode(String code) {
		if (code == null)
			return null;
		return code.replaceAll("\\s+", " ");
	}

	public static CompareResult compare(List<RefactorRecord> eclipseList, List<RefactorRecord> ideaList) {
		CompareResult result = new CompareResult();
		Map<String, RefactorRecord> ideaMap = new HashMap<>();
		for (RefactorRecord rec : ideaList) {
			ideaMap.put(buildKey(rec), rec);
		}

		for (RefactorRecord eRec : eclipseList) {
			String key = buildKey(eRec);
			RefactorRecord iRec = ideaMap.get(key);
			if (iRec == null)
				continue;

			String eFile = getLocalFilePath(ECLIPSE_PROJECT_ROOT, eRec.sourceFilePath);
			String iFile = getLocalFilePath(IDEA_PROJECT_ROOT, iRec.sourceFilePath);
			RefactorPair pair = new RefactorPair(eRec, iRec, eFile, iFile);

			String eCode = null;
			String iCode = null;
			try {
				eCode = readFileText(eFile);
				iCode = readFileText(iFile);
			} catch (IOException ex) {
				result.compileErrorCandidateList.add(pair);
				continue;
			}

			if (eRec.success != iRec.success) {
				result.inconsistentSuccessList.add(pair);
			}

			if (eRec.success && iRec.success) {
				String eNorm = normalizeCode(eCode);
				String iNorm = normalizeCode(iCode);
				if (!Objects.equals(eNorm, iNorm)) {
					result.successButCodeDiffList.add(pair);
				}
			}
		}
		return result;
	}

	public static void main(String[] args) {
		try {
			String eclipseJson = "D:/runtime-EclipseApplication/TEST/refactor_result_extract_variable.json";
			String ideaJson = "D:/IDEA/output_extract_var.json";

			List<RefactorRecord> eclipseRecords = loadJson(eclipseJson);
			List<RefactorRecord> ideaRecords = loadJson(ideaJson);

			CompareResult res = compare(eclipseRecords, ideaRecords);

			System.out.println("===== 1. 文件读取异常候选 总数:" + res.compileErrorCandidateList.size() + " =====");
			for (RefactorPair p : res.compileErrorCandidateList) {
				RefactorRecord r = p.eclipseRec;
				System.out.printf("%s.%s | file=%s%n", r.packageName, r.className, r.sourceFilePath);
			}

			System.out.println("\n===== 2. 重构执行不一致（一个成功，一个失败） 总数:" + res.inconsistentSuccessList.size() + " =====");
			for (RefactorPair p : res.inconsistentSuccessList) {
				RefactorRecord e = p.eclipseRec;
				RefactorRecord i = p.ideaRec;
				System.out.printf("%s.%s | eclipse=%s, idea=%s | oldVar:%s, newVar:%s | %s%n", e.packageName,
						e.className, e.success, i.success, e.oldVariableName, e.newVariableName, e.sourceFilePath);
			}

			System.out.println("\n===== 3. 两边重构成功，但代码文本不同 总数:" + res.successButCodeDiffList.size() + " =====");
			for (RefactorPair p : res.successButCodeDiffList) {
				RefactorRecord e = p.eclipseRec;
				System.out.printf("%s.%s | oldVar:%s, newVar:%s | %s%n", e.packageName, e.className, e.oldVariableName,
						e.newVariableName, e.sourceFilePath);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static List<RefactorRecord> loadJson(String path) throws IOException {
		try (FileReader reader = new FileReader(path)) {
			return gson.fromJson(reader, new TypeToken<List<RefactorRecord>>() {
			}.getType());
		}
	}
}
