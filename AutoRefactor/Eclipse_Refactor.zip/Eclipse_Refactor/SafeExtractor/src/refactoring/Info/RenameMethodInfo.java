package refactoring.Info;

public class RenameMethodInfo {
	public String packageName;
	public String className;
	public String oldMethodName;
	public String newMethodName;
	public String sourceFilePath;
	public boolean success;
	public String message;
	public int offset;
	public int length;
}
