package refactoring.Info;

public class ExtractMethodInfo {
	public String packageName;
	public String className;
	public String sourceMethodName;
	public String newMethodName;
	public String sourceFilePath;
	public int extractOffset;
	public int extractLength;
	public boolean success;
	public String message;
}
