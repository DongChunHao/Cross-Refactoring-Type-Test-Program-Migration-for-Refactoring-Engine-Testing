package refactoring.Info;

public class RenameVariableInfo {
	public String packageName;
	public String className;
	public String methodName;
	public String oldVarName;
	public String newVarName;
	public boolean success;
	public String message;
	public int offset;
	public int length;
	public String sourceFilePath;
	public String refactoringType = "Rename LocalVariable";
}
