package refactoring.Info;

public class MoveMethodInfo {
	public String sourcePackageName;
	public String sourceClassName;
	public String methodName;
	public String targetClassName;
	public String targetPackageName;
	public String sourceFilePath;
	public boolean success;
	public String message;
	public int offset;
	public int length;
}
