package refactoring.Info;

public class ExtractVariableInfo {
	public String packageName;
	public String className;
	public String methodName;
	public String sourceFilePath;
	public String oldVariableName;
	public String newVariableName;
	public int extractOffset;
	public int extractLength;
	public boolean success;
	public String message;
	public String exprText;
}
