package refactoring.Info;

public class RenameFieldInfo {
	public String packageName;
	public String className;
	public String oldFieldName;
	public String newFieldName;
	public String sourceFilePath;
	public boolean success;
	public String message;
	public int offset;
	public int length;

}
