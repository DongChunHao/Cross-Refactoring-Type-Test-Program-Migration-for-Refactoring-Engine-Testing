package refactoring.Info;

public class InlineMethodInfo {
	public String packageName;
	public String className;
	public String methodName;
	public String sourceFilePath;
	public boolean success;
	public String message;
	public int offset;
	public int length;
}
