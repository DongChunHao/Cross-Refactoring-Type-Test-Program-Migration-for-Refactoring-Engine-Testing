package refactoring.handlers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.EmptyStatement;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.Statement;
import org.eclipse.jdt.internal.corext.refactoring.code.ExtractMethodRefactoring;
import org.eclipse.jdt.internal.corext.refactoring.util.RefactoringASTParser;
import org.eclipse.ltk.core.refactoring.PerformRefactoringOperation;
import org.eclipse.ltk.core.refactoring.RefactoringStatus;

import com.alibaba.fastjson.JSON;

import refactoring.Info.ExtractMethodInfo;
import refactoring.file.parse.GetProject;

public class ExtractMethodHanlder {

	public static void handlerExtractMethod(ExecutionEvent event) {
		String refactoringProjectName = "TEST";
		List<ExtractMethodInfo> allRefactoringRecords = new ArrayList<>();
		String targetMethodName = "refMethod";
		Random random = new Random();
		try {
			IJavaProject javaProject = GetProject.getJavaProject(refactoringProjectName);
			List<ICompilationUnit> cuList = getAllCompilationUnits(javaProject);

			for (ICompilationUnit cu : cuList) {
				if (cu.hasUnsavedChanges()) {
					cu.save(new NullProgressMonitor(), true);
				}
				String cuFilePath = cu.getResource().getFullPath().toString();
				String packageName = "";
				if (cu.getPackageDeclarations() != null && cu.getPackageDeclarations().length > 0) {
					packageName = cu.getPackageDeclarations()[0].getElementName();
				}

				RefactoringASTParser parser = new RefactoringASTParser(AST.getJLSLatest());
				CompilationUnit astRoot = parser.parse(cu, true);
				String sourceCode = cu.getSource();

				IType[] allTypes = cu.getAllTypes();
				for (IType type : allTypes) {
					String className = type.getElementName();
					for (IMethod targetMethod : type.getMethods()) {
						if (!targetMethod.getElementName().equals(targetMethodName)) {
							continue;
						}
						ExtractMethodInfo item = new ExtractMethodInfo();
						item.packageName = packageName;
						item.className = className;
						item.sourceMethodName = targetMethod.getElementName();
						item.sourceFilePath = cuFilePath;
						item.newMethodName = "";
						item.extractOffset = -1;
						item.extractLength = -1;
						item.success = false;
						item.message = "";

						String marker = "/*EXTRACT*/";
						int markerPos = sourceCode.indexOf(marker);
						if (markerPos == -1) {
							item.message = "源码未找到 /*EXTRACT*/";
							System.out.println("源码未找到 /*EXTRACT*/");
							allRefactoringRecords.add(item);
							continue;
						}
						int markerEndPos = markerPos + marker.length();

						final List<Statement> allCandidates = new ArrayList<>();
						ASTVisitor collectVisitor = new ASTVisitor(true) {
							@Override
							public boolean visit(MethodDeclaration methodDecl) {
								Block body = methodDecl.getBody();
								if (body == null)
									return false;
								List<Statement> stmtsInBlock = body.statements();
								boolean startCollect = false;
								for (Statement stmt : stmtsInBlock) {
									int stmtStart = stmt.getStartPosition();
									if (!startCollect) {
										if (stmtStart > markerEndPos) {
											startCollect = true;
											if (!(stmt instanceof EmptyStatement)) {
												allCandidates.add(stmt);
											}
										}
									} else {
										if (!(stmt instanceof EmptyStatement)) {
											allCandidates.add(stmt);
										}
									}
								}
								return false;
							}
						};
						astRoot.accept(collectVisitor);

						if (allCandidates.isEmpty()) {
							item.message = "EXTRACT后没有找到有效语句，跳过";
							System.out.println("EXTRACT后没有找到有效语句，跳过");
							allRefactoringRecords.add(item);
							continue;
						}
						int maxAvailable = allCandidates.size();

						int pickCount = random.nextInt(maxAvailable) + 1;
						List<Statement> selectedStmts = allCandidates.subList(0, pickCount);

						Statement firstStmt = selectedStmts.get(0);
						Statement lastStmt = selectedStmts.get(selectedStmts.size() - 1);
						int extractOffset = firstStmt.getStartPosition();
						int extractEnd = lastStmt.getStartPosition() + lastStmt.getLength();
						int extractLen = extractEnd - extractOffset;
						item.extractOffset = extractOffset;
						item.extractLength = extractLen;

						System.out.printf("提取方法：maxAvailable=%d, pickCount=%d, offset=%d, len=%d%n", maxAvailable,
								pickCount, extractOffset, extractLen);
//						String newMethodName = generateNewMethodName(type, targetMethod);
						String newMethodName = "extracted";
						item.newMethodName = newMethodName;
						ExtractMethodRefactoring refactoring = null;
						try {
							Class<ExtractMethodRefactoring> cls = ExtractMethodRefactoring.class;
							java.lang.reflect.Constructor<ExtractMethodRefactoring> ctor = cls
									.getDeclaredConstructor(ICompilationUnit.class, int.class, int.class);
							ctor.setAccessible(true);
							refactoring = ctor.newInstance(cu, extractOffset, extractLen);
							refactoring.setMethodName(newMethodName);
						} catch (Exception e) {
							item.message = "反射构造ExtractMethodRefactoring失败:" + e.getMessage();
							e.printStackTrace();
							allRefactoringRecords.add(item);
							continue;
						}

						IProgressMonitor monitor = new NullProgressMonitor();
						RefactoringStatus statusInitial = refactoring.checkInitialConditions(monitor);
						if (statusInitial.hasError() || statusInitial.hasWarning()) {
							String msg = statusInitial.getMessageMatchingSeverity(RefactoringStatus.ERROR);
							if (msg == null) {
								msg = statusInitial.getMessageMatchingSeverity(RefactoringStatus.WARNING);
							}
							item.message = "前置校验存在错误/警告，不执行重构：" + msg;
							System.err.println("提取方法前置校验冲突：" + msg);
							allRefactoringRecords.add(item);
							continue;
						}
						RefactoringStatus statusFinal = refactoring.checkFinalConditions(monitor);
						if (statusFinal.hasError() || statusFinal.hasWarning()) {
							String msg = statusFinal.getMessageMatchingSeverity(RefactoringStatus.ERROR);
							if (msg == null) {
								msg = statusFinal.getMessageMatchingSeverity(RefactoringStatus.WARNING);
							}
							item.message = "最终校验存在错误/警告，不执行重构：" + msg;
							System.err.println("提取方法最终校验冲突：" + msg);
							allRefactoringRecords.add(item);
							continue;
						}

						try {
							PerformRefactoringOperation op = new PerformRefactoringOperation(refactoring, 3);
							op.run(monitor);
							item.success = true;
							item.message = "extract method successfully.";
							System.out.println("提取方法重构执行成功");
						} catch (CoreException e) {
							item.message = "提取方法重构异常:" + e.getMessage();
							e.printStackTrace();
							System.err.println("提取方法重构异常");
						}
						allRefactoringRecords.add(item);
					}
				}
			}

			String jsonResult = JSON.toJSONString(allRefactoringRecords);
			String projectPath = javaProject.getResource().getLocation().toOSString();
			String outputFile = projectPath + java.io.File.separator + "refactor_result_extract_method.json";
			try (java.io.FileWriter writer = new java.io.FileWriter(outputFile)) {
				writer.write(jsonResult);
				writer.flush();
				System.out.println("==== 提取方法重构结果已保存到 " + outputFile + "====");
			} catch (java.io.IOException ioEx) {
				ioEx.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//	public void readDataInfo(String projectName) throws CoreException {
//		List<ExtractMethodInfo> allDataInfo = ExtractMethodData.readJson(projectName);
//		IJavaProject javaProject;
//		javaProject = GetProject.getJavaProject(projectName);
//		IWorkspace workspace = ResourcesPlugin.getWorkspace();
//		for (int i = 0; i < allDataInfo.size(); i++) {
//			boolean isSuccess = false;
//			ExtractMethodInfo methodInfo = allDataInfo.get(i);
//			IPath path = Path.fromOSString(methodInfo.getPath().replaceAll("IDEA", "Eclipse"));
//			IFile file = workspace.getRoot().getFileForLocation(path);
//			IJavaElement element = JavaCore.create(file);
//			ICompilationUnit iCompilationUnit = (ICompilationUnit) element;
//			if (iCompilationUnit != null) {
//				// 获取选定的range
//				performExtractMethodRefactoring(allDataInfo.get(i).getOffset(), allDataInfo.get(i).getLength(),
//						allDataInfo.get(i).getMethod(), isSuccess);
//				saveRefactoringData(iCompilationUnit, methodInfo);
//				ResultJson.handleAPIJsonFile(methodInfo.getNo(), isSuccess);// 存储是否能重构记录
//				if (file.exists()) {
//					try {
//						TextFileChange textFileChange = new TextFileChange("Sample Change", file);
//						UndoHistory.undoRefactoringHistory(file);
//						file.refreshLocal(IFile.DEPTH_INFINITE, new NullProgressMonitor());
//					} catch (Exception e) {
//						e.printStackTrace();
//					}
//				} else {
//					System.out.println("File does not exist");
//				}
//			}
//		}
//	}

	public void performExtractMethodRefactoring(int start, int length, String methodName, boolean isSuccess) {
		ICompilationUnit unit = null;
		ExtractMethodRefactoring refactoring = new ExtractMethodRefactoring(unit, start, length);
		refactoring.setMethodName(methodName);
		try {
			if (refactoring.checkInitialConditions(new NullProgressMonitor()).isOK()
					&& refactoring.checkFinalConditions(new NullProgressMonitor()).isOK()) {
				System.out.println("执行重构");
				isSuccess = true;
				final PerformRefactoringOperation op = new PerformRefactoringOperation(refactoring, 0);
				JavaCore.run(op, new NullProgressMonitor());
			} else {
				System.out.println("不能重构");
			}
		} catch (CoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

//	public void saveRefactoringData(ICompilationUnit iCompilationUnit, ExtractMethodInfo extractMethodInfo)
//			throws JavaModelException {
//		String fileContent = iCompilationUnit.getSource();
//		SaveFile.saveContentToFile("D:\\IDEA_build\\saveFile\\Eclipse\\" + extractMethodInfo.getProjectName()
//				+ "\\ExtractVariable\\" + extractMethodInfo.getNo() + "\\" + extractMethodInfo.getTypeName() + ".java",
//				fileContent);
//	}
//
//	public static List<ICompilationUnit> getAllCompilationUnits(IJavaProject javaProject) throws JavaModelException {
//		List<ICompilationUnit> units = new ArrayList<>();
//		IPackageFragmentRoot[] roots = javaProject.getPackageFragmentRoots();
//		for (IPackageFragmentRoot root : roots) {
//			// 判断是否为源码目录，排除jar包等库
//			if (root.getKind() == IPackageFragmentRoot.K_SOURCE) {
//				// 获取root下所有子元素（包）
//				IJavaElement[] children = root.getChildren();
//				for (IJavaElement child : children) {
//					if (child instanceof IPackageFragment) {
//						IPackageFragment pkg = (IPackageFragment) child;
//						ICompilationUnit[] cus = pkg.getCompilationUnits();
//						units.addAll(List.of(cus));
//					}
//				}
//			}
//		}
//		return units;
//	}

	private static String generateNewMethodName(IType targetType, IMethod oldMethod) throws CoreException {
		// 两种策略：0=随机生成合法字段名，1=复用当前类的方法名
		List<Integer> strategyList = Arrays.asList(0, 1);
		int selectedStrategy = strategyList.get(new Random().nextInt(strategyList.size()));
		String oldName = oldMethod.getElementName();

		String newName;
		switch (selectedStrategy) {
		case 0:
			// 策略1：随机生成合法标识符作为字段名
			newName = generateRandomIdentifier();
			break;
		case 1:
			// 策略2：遍历当前类所有方法，挑选方法名作为新字段名
			IMethod[] allMethods = targetType.getMethods();
			List<String> existMethodNames = new ArrayList<>();
			for (IMethod method : allMethods) {
				String mname = method.getElementName();
				// 排除和旧字段同名的，避免冲突
				if (!mname.equals(oldName)) {
					existMethodNames.add(mname);
				}
			}
			if (!existMethodNames.isEmpty()) {
				newName = existMethodNames.get(new Random().nextInt(existMethodNames.size()));
			} else {
				// 类里面没有方法，降级随机生成
				newName = generateRandomIdentifier();
			}
			break;
		default:
			newName = generateRandomIdentifier();
		}
		return newName;
	}

	private static String generateRandomIdentifier() {
		Random random = new Random();
		// 首字符必须是字母
		char first = (char) ('a' + random.nextInt(26));
		StringBuilder sb = new StringBuilder();
		sb.append(first);
		// 后面追加 3~6 个字母数字
		int len = 3 + random.nextInt(4);
		for (int i = 0; i < len; i++) {
			if (random.nextBoolean()) {
				sb.append((char) ('a' + random.nextInt(26)));
			} else {
				sb.append(random.nextInt(10));
			}
		}
		return sb.toString();
	}

	public static List<ICompilationUnit> getAllCompilationUnits(IJavaProject javaProject) throws JavaModelException {
		List<ICompilationUnit> units = new ArrayList<>();
		IPackageFragmentRoot[] roots = javaProject.getPackageFragmentRoots();
		for (IPackageFragmentRoot root : roots) {
			// 判断是否为源码目录，排除jar包等库
			if (root.getKind() == IPackageFragmentRoot.K_SOURCE) {
				// 获取root下所有子元素（包）
				IJavaElement[] children = root.getChildren();
				for (IJavaElement child : children) {
					if (child instanceof IPackageFragment) {
						IPackageFragment pkg = (IPackageFragment) child;
						ICompilationUnit[] cus = pkg.getCompilationUnits();
						units.addAll(List.of(cus));
					}
				}
			}
		}
		return units;
	}

}
