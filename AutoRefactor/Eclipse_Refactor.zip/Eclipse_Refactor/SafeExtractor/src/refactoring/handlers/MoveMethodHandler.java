package refactoring.handlers;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IPackageDeclaration;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.ISourceRange;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.IBinding;
import org.eclipse.jdt.core.dom.IPackageBinding;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.IVariableBinding;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
import org.eclipse.jdt.internal.corext.refactoring.structure.MoveInstanceMethodProcessor;
import org.eclipse.jdt.internal.ui.preferences.JavaPreferencesSettings;
import org.eclipse.ltk.core.refactoring.PerformRefactoringOperation;
import org.eclipse.ltk.core.refactoring.Refactoring;
import org.eclipse.ltk.core.refactoring.RefactoringStatus;
import org.eclipse.ltk.core.refactoring.participants.MoveRefactoring;

import com.alibaba.fastjson.JSON;

import ast.Entity.Entity;
import refactoring.Info.MoveMethodInfo;
import refactoring.file.parse.GetProject;
import refactoring.random.type.PerformRefactoring;

public class MoveMethodHandler {

	static void handlerMoveMethod(ExecutionEvent event) {
		String refactoringProjectName = "TEST";
		IJavaProject javaProject;
		List<MoveMethodInfo> allRefactoringRecords = new ArrayList<>();
		String targetMethodName = "methodToBeMoved";

		try {
			javaProject = GetProject.getJavaProject(refactoringProjectName);
			List<ICompilationUnit> cuList = getAllCompilationUnits(javaProject);

			for (ICompilationUnit cu : cuList) {
				// 保存文件，保证JDT模型和磁盘源码一致，解决stale元素问题
				if (cu.hasUnsavedChanges()) {
					cu.save(new NullProgressMonitor(), true);
				}
				String cuFilePath = cu.getResource().getFullPath().toString();
				String packageName = "";
				IPackageDeclaration[] pkgDecls = cu.getPackageDeclarations();
				if (pkgDecls != null && pkgDecls.length > 0) {
					packageName = pkgDecls[0].getElementName();
				}
				IType[] allTypes = cu.getAllTypes();

				for (IType type : allTypes) {
					String sourceClassName = type.getElementName();
					IMethod[] methods = type.getMethods();
					for (IMethod iMethod : methods) {
						String oldName = iMethod.getElementName();
						if (!oldName.equals(targetMethodName)) {
							continue;
						}
						// 新建记录对象，无论成功失败都会保存
						MoveMethodInfo item = new MoveMethodInfo();
						item.sourcePackageName = packageName;
						item.sourceClassName = sourceClassName;
						item.methodName = oldName;
						item.sourceFilePath = cuFilePath;
						item.success = false;
						item.message = "";
						String targetClassName = "";
						String targetPackageName = "";

						// 获取方法源码偏移位置
						try {
							ISourceRange range = iMethod.getSourceRange();
							item.offset = range.getOffset();
							item.length = range.getLength();
						} catch (CoreException e) {
							item.offset = -1;
							item.length = -1;
							item.message += "获取源码位置失败:" + e.getMessage() + ";";
						}

						Entity methodEntity = new Entity(iMethod);
						MethodDeclaration methodDeclaration = (MethodDeclaration) methodEntity.getAssociatedNode();
						CompilationUnit cUnit = (CompilationUnit) methodEntity.getUnit();

						IVariableBinding[] targetFieldBindingArr = new IVariableBinding[1];
						ASTVisitor visitor = new ASTVisitor() {
							@Override
							public boolean visit(FieldDeclaration node) {
								for (VariableDeclarationFragment frag : (List<VariableDeclarationFragment>) node
										.fragments()) {
									if ("a".equals(frag.getName().getIdentifier())) {
										IBinding binding = frag.resolveBinding();
										if (binding instanceof IVariableBinding varBinding) {
											targetFieldBindingArr[0] = varBinding;
										}
									}
								}
								return false;
							}
						};
						cUnit.accept(visitor);
						IVariableBinding targetFieldBinding = targetFieldBindingArr[0];
						if (targetFieldBinding == null) {
							item.message = "找不到字段 a 的 IVariableBinding";
							System.err.println("找不到字段 a 的 IVariableBinding");
							allRefactoringRecords.add(item);
							continue;
						}
						// 获取目标类名称
						ITypeBinding targetTypeBinding = targetFieldBinding.getType();
						if (targetTypeBinding != null) {
							targetClassName = targetTypeBinding.getName();
							IPackageBinding pkgBinding = targetTypeBinding.getPackage();
							if (pkgBinding != null) {
								targetPackageName = pkgBinding.getName();
							}
						}
						item.targetClassName = targetClassName;
						item.targetPackageName = targetPackageName;
						MoveInstanceMethodProcessor processor = new MoveInstanceMethodProcessor(iMethod,
								JavaPreferencesSettings.getCodeGenerationSettings(javaProject));
						processor.setTarget(targetFieldBinding);
						processor.setTargetName("sourceObj");
						processor.setDelegateUpdating(false);

						Refactoring ref = new MoveRefactoring(processor);
						IProgressMonitor monitor = new NullProgressMonitor();

						try {
							RefactoringStatus result1 = ref.checkInitialConditions(monitor);
							System.out.println("===== MoveMethod checkInitialConditions status：" + result1.toString());
							if (result1.hasError() || result1.hasWarning()) {
								String errMsg = result1.getMessageMatchingSeverity(RefactoringStatus.ERROR);
								if (errMsg == null) {
									errMsg = result1.getMessageMatchingSeverity(RefactoringStatus.WARNING);
								}
								item.message = "前置检查存在冲突(警告/错误)：" + errMsg;
								System.err.println("文件:" + cuFilePath + " 前置检查存在冲突：" + errMsg);
							} else {
								RefactoringStatus result2 = ref.checkFinalConditions(monitor);
								System.out
										.println("===== MoveMethod checkFinalConditions status：" + result2.toString());
								if (result2.hasError() || result2.hasWarning()) {
									String errMsg = result2.getMessageMatchingSeverity(RefactoringStatus.ERROR);
									if (errMsg == null) {
										errMsg = result2.getMessageMatchingSeverity(RefactoringStatus.WARNING);
									}
									item.message = "后置检查存在冲突(警告/错误)：" + errMsg;
									System.err.println("文件:" + cuFilePath + " 后置检查存在冲突：" + errMsg);
								} else {
									PerformRefactoringOperation op = new PerformRefactoringOperation(ref, 2);
									op.run(monitor);
									item.success = true;
									item.message = "move method successfully.";
									System.out.println("文件:" + cuFilePath + " Move method successfully.");
									PerformRefactoring.no += 1;
								}
							}
						} catch (CoreException e) {
							item.message = "重构执行异常:" + e.getMessage();
							System.err.println("文件:" + cuFilePath + " 移动方法执行异常：" + e.getMessage());
							e.printStackTrace();
						}
						allRefactoringRecords.add(item);
						// 保留break：一个类找到第一个methodToBeMoved就停止处理当前类剩余方法
						break;
					}
				}
			}

			String jsonResult = JSON.toJSONString(allRefactoringRecords);
			// 输出到TEST项目根目录
			String projectPath = javaProject.getResource().getLocation().toOSString();
			String outputFile = projectPath + java.io.File.separator + "refactor_result_move_method.json";
			try (java.io.FileWriter writer = new java.io.FileWriter(outputFile)) {
				writer.write(jsonResult);
				writer.flush();
				System.out.println("==== 所有Java文件移动方法重构结果已全部保存到 " + outputFile + "====");
			} catch (java.io.IOException ioEx) {
				ioEx.printStackTrace();
			}

		} catch (CoreException e1) {
			e1.printStackTrace();
		}
	}

	public static IType getType(IType[] iTypes, String typeName) {
		for (IType type : iTypes) {
			if (typeName.equals(type.getFullyQualifiedName())) {
				return type;
			}
		}
		return null;
	}

	private static IMethod setMethods(IJavaElement element, String methodName, String[] paraTypes) {
		if (element instanceof IType) {
			IType type = (IType) element;
			IMethod[] approches = null;
			try {
				approches = type.getMethods();
			} catch (JavaModelException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			for (IMethod method : approches) {
				String[] currMethod = method.getParameterTypes();
				if (currMethod.equals(paraTypes) && method.getElementName().equals(methodName)) {
					return method;
				}
			}
		}
		return null;
	}

	public static List<ICompilationUnit> getAllCompilationUnits(IJavaProject javaProject) throws JavaModelException {
		List<ICompilationUnit> units = new ArrayList<>();
		IPackageFragmentRoot[] roots = javaProject.getPackageFragmentRoots();
		for (IPackageFragmentRoot root : roots) {
			// 判断是否为源码目录，排除jar包等库
			if (root.getKind() == IPackageFragmentRoot.K_SOURCE) {
				// 获取root下所有子元素（包）
				IJavaElement[] children = root.getChildren();
				for (IJavaElement child : children) {
					if (child instanceof IPackageFragment) {
						IPackageFragment pkg = (IPackageFragment) child;
						ICompilationUnit[] cus = pkg.getCompilationUnits();
						units.addAll(List.of(cus));
					}
				}
			}
		}
		return units;
	}

}
