package refactoring.handlers;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IPackageDeclaration;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.ISourceRange;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.internal.corext.refactoring.code.InlineMethodRefactoring;
import org.eclipse.jdt.internal.corext.refactoring.util.RefactoringASTParser;
import org.eclipse.ltk.core.refactoring.PerformRefactoringOperation;
import org.eclipse.ltk.core.refactoring.RefactoringStatus;

import com.alibaba.fastjson.JSON;

import refactoring.Info.InlineMethodInfo;
import refactoring.file.parse.GetProject;

public class InlineMethodHandler {

	public static void handlerInlineMethod(ExecutionEvent event) {
		String refactoringProjectName = "TEST";
		IJavaProject javaProject;
		List<InlineMethodInfo> allRefactoringRecords = new ArrayList<>();
		String targetMethodName = "methodToBeInlined";
		try {
			javaProject = GetProject.getJavaProject(refactoringProjectName);
			List<ICompilationUnit> cuList = getAllCompilationUnits(javaProject);
			for (ICompilationUnit cu : cuList) {
				if (cu.hasUnsavedChanges()) {
					cu.save(new NullProgressMonitor(), true);
				}
				String cuFilePath = cu.getResource().getFullPath().toString();
				String packageName = "";
				IPackageDeclaration[] pkgDecls = cu.getPackageDeclarations();
				if (pkgDecls != null && pkgDecls.length > 0) {
					packageName = pkgDecls[0].getElementName();
				}
				IType[] allTypes = cu.getAllTypes();
				for (IType type : allTypes) {
					String className = type.getElementName();
					for (IMethod iMethod : type.getMethods()) {
						if (!iMethod.getElementName().equals(targetMethodName)) {
							continue;
						}
						InlineMethodInfo item = new InlineMethodInfo();
						item.packageName = packageName;
						item.className = className;
						item.methodName = iMethod.getElementName();
						item.sourceFilePath = cuFilePath;
						item.success = false;
						item.message = "";
						item.offset = -1;
						item.length = -1;

						ISourceRange nameRange = iMethod.getNameRange();
						if (nameRange == null) {
							item.message = "nameRange 为 null";
							System.err.println("nameRange 为 null");
							allRefactoringRecords.add(item);
							continue;
						}
						int offset = nameRange.getOffset();
						int len = nameRange.getLength();
						item.offset = offset;
						item.length = len;

						System.out.println("准备内联方法：" + iMethod.getElementName() + " offset=" + nameRange.getOffset()
								+ " length=" + nameRange.getLength());

						RefactoringASTParser parser = new RefactoringASTParser(AST.getJLSLatest());
						CompilationUnit astRoot = parser.parse(cu, true);

						InlineMethodRefactoring refactoring = InlineMethodRefactoring.create(cu, astRoot,
								nameRange.getOffset(), nameRange.getLength());

						IProgressMonitor monitor = new NullProgressMonitor();

						RefactoringStatus statusInitial = refactoring.checkInitialConditions(monitor);
						if (statusInitial.hasError() || statusInitial.hasWarning()) {
							String msg = statusInitial.getMessageMatchingSeverity(RefactoringStatus.ERROR);
							if (msg == null) {
								msg = statusInitial.getMessageMatchingSeverity(RefactoringStatus.WARNING);
							}
							item.message = "前置校验存在错误/警告，不执行重构：" + msg;
							System.err.println("Inline前置校验冲突：" + msg);
							allRefactoringRecords.add(item);
							continue;
						}

						RefactoringStatus statusFinal = refactoring.checkFinalConditions(monitor);
						if (statusFinal.hasError() || statusFinal.hasWarning()) {
							String msg = statusFinal.getMessageMatchingSeverity(RefactoringStatus.ERROR);
							if (msg == null) {
								msg = statusFinal.getMessageMatchingSeverity(RefactoringStatus.WARNING);
							}
							item.message = "最终校验存在错误/警告，不执行重构：" + msg;
							System.err.println("Inline最终校验冲突：" + msg);
							allRefactoringRecords.add(item);
							continue;
						}

						try {
							PerformRefactoringOperation op = new PerformRefactoringOperation(refactoring, 3);
							JavaCore.run(op, monitor);
							item.success = true;
							item.message = "inline method successfully.";
							System.out.println("Inline全部调用点内联成功（API内部自动应用修改）");
						} catch (CoreException e) {
							item.message = "重构执行异常:" + e.getMessage();
							System.err.println("Inline重构执行异常");
							e.printStackTrace();
						}
						allRefactoringRecords.add(item);
					}
				}
			}
			String jsonResult = JSON.toJSONString(allRefactoringRecords);
			String projectPath = javaProject.getResource().getLocation().toOSString();
			String outputFile = projectPath + java.io.File.separator + "refactor_result_inline_method.json";
			try (java.io.FileWriter writer = new java.io.FileWriter(outputFile)) {
				writer.write(jsonResult);
				writer.flush();
				System.out.println("==== 内联方法重构结果已保存到 " + outputFile + "====");
			} catch (java.io.IOException ioEx) {
				ioEx.printStackTrace();
			}
		} catch (CoreException e1) {
			e1.printStackTrace();
		}
	}

	public static IType getType(IType[] iTypes, String typeName) {
		for (IType type : iTypes) {
			if (typeName.equals(type.getFullyQualifiedName())) {
				return type;
			}
		}
		return null;
	}

	private static IMethod setMethods(IJavaElement element, String methodName, String[] paraTypes) {
		if (element instanceof IType) {
			IType type = (IType) element;
			IMethod[] approches = null;
			try {
				approches = type.getMethods();
			} catch (JavaModelException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			for (IMethod method : approches) {
				String[] currMethod = method.getParameterTypes();
				if (currMethod.equals(paraTypes) && method.getElementName().equals(methodName)) {
					return method;
				}
			}
		}
		return null;
	}

	public static List<ICompilationUnit> getAllCompilationUnits(IJavaProject javaProject) throws JavaModelException {
		List<ICompilationUnit> units = new ArrayList<>();
		IPackageFragmentRoot[] roots = javaProject.getPackageFragmentRoots();
		for (IPackageFragmentRoot root : roots) {
			// 判断是否为源码目录，排除jar包等库
			if (root.getKind() == IPackageFragmentRoot.K_SOURCE) {
				// 获取root下所有子元素（包）
				IJavaElement[] children = root.getChildren();
				for (IJavaElement child : children) {
					if (child instanceof IPackageFragment) {
						IPackageFragment pkg = (IPackageFragment) child;
						ICompilationUnit[] cus = pkg.getCompilationUnits();
						units.addAll(List.of(cus));
					}
				}
			}
		}
		return units;
	}
}
