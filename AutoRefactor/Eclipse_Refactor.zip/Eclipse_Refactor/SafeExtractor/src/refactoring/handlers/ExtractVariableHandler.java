package refactoring.handlers;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IField;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.ILocalVariable;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IPackageDeclaration;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;
import org.eclipse.jdt.internal.corext.refactoring.code.ExtractTempRefactoring;
import org.eclipse.jdt.internal.corext.refactoring.util.RefactoringASTParser;
import org.eclipse.jdt.internal.ui.refactoring.RefactoringExecutionHelper;
import org.eclipse.jdt.ui.refactoring.RefactoringSaveHelper;
import org.eclipse.ltk.core.refactoring.PerformRefactoringOperation;
import org.eclipse.ltk.core.refactoring.RefactoringCore;
import org.eclipse.ltk.core.refactoring.RefactoringStatus;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.PlatformUI;

import com.alibaba.fastjson.JSON;

import refactoring.Info.ExpressionInfo;
import refactoring.Info.ExtractVariableInfo;
import refactoring.file.parse.GetProject;
import refactoring.handlers.RenameVariableHandler.MethodDeclarationVisitor;
import refactoring.visitor.EclipseExtractTempRefactoring;

public class ExtractVariableHandler {
	public static ArrayList<Integer> extractList;
	static List<String> noFindList = new ArrayList<>();
	static List<ExpressionInfo> saveExpression = new ArrayList<>();

	public static void handlerExtractVariable(ExecutionEvent event) {
		String refactoringProjectName = "TEST";
		List<ExtractVariableInfo> allRefactoringRecords = new ArrayList<>();
		String targetMethodName = "refMethod";
		try {
			IJavaProject javaProject = GetProject.getJavaProject(refactoringProjectName);
			List<ICompilationUnit> cuList = getAllCompilationUnits(javaProject);

			for (ICompilationUnit cu : cuList) {
				if (cu.hasUnsavedChanges()) {
					cu.save(new NullProgressMonitor(), true);
				}
				String cuFilePath = cu.getResource().getFullPath().toString();
				String packageName = "";
				IPackageDeclaration[] pkgDecls = cu.getPackageDeclarations();
				if (pkgDecls != null && pkgDecls.length > 0) {
					packageName = pkgDecls[0].getElementName();
				}

				RefactoringASTParser parser = new RefactoringASTParser(AST.getJLSLatest());
				CompilationUnit astRoot = parser.parse(cu, true);

				IType[] allTypes = cu.getAllTypes();
				for (IType type : allTypes) {
					String className = type.getElementName();
					for (IMethod targetMethod : type.getMethods()) {

						if (!targetMethod.getElementName().equals(targetMethodName)) {
							continue;
						}
						ExtractVariableInfo item = new ExtractVariableInfo();
						item.packageName = packageName;
						item.className = className;
						item.methodName = targetMethod.getElementName();
						item.sourceFilePath = cuFilePath;
						item.success = false;
						item.message = "";
						item.oldVariableName = "";
						item.newVariableName = "";
						item.extractOffset = -1;
						item.extractLength = -1;
						item.exprText = ""; // 新增表达式文本字段

						String sourceCode = cu.getSource();
						String marker = "/*EXTRACT*/";
						int markerPos = sourceCode.indexOf(marker);
						if (markerPos == -1) {
							item.message = "源码中未找到 /*EXTRACT*/ 标记";
							System.out.println("源码中未找到 /*EXTRACT*/ 标记");
							allRefactoringRecords.add(item);
							continue;
						}
						int markerEndPos = markerPos + marker.length();

						final int[] exprOffsetAndLen = new int[2];
						exprOffsetAndLen[0] = -1;
						final String[] exprTextHolder = new String[1]; // 用来存表达式文本
						ASTVisitor visitor = new ASTVisitor(true) {
							public boolean visit(VariableDeclarationStatement varStmt) {
								int stmtStart = varStmt.getStartPosition();
								if (stmtStart > markerEndPos && exprOffsetAndLen[0] == -1) {
									Object fragObj = varStmt.fragments().get(0);
									if (fragObj instanceof VariableDeclarationFragment frag) {
										item.oldVariableName = frag.getName().getIdentifier();
										Expression initExpr = frag.getInitializer();
										if (initExpr != null) {
											exprOffsetAndLen[0] = initExpr.getStartPosition();
											exprOffsetAndLen[1] = initExpr.getLength();
											exprTextHolder[0] = initExpr.toString(); // 采集表达式文本
										}
									}
								}
								return true;
							}
						};
						astRoot.accept(visitor);

						int exprOffset = exprOffsetAndLen[0];
						int exprLen = exprOffsetAndLen[1];
						if (exprOffset == -1) {
							item.message = "未找到 /*EXTRACT*/ 后的可提取表达式，跳过";
							System.out.println("未找到 /*EXTRACT*/ 后的可提取表达式，跳过");
							allRefactoringRecords.add(item);
							continue;
						}
						item.extractOffset = exprOffset;
						item.extractLength = exprLen;
						item.exprText = exprTextHolder[0];
						System.out.println(
								"找到待提取表达式 offset:" + exprOffset + " len:" + exprLen + " expr:" + item.exprText);

						ExtractTempRefactoring refactoring = null;
						String newVar = "";
						try {
							Class<ExtractTempRefactoring> cls = ExtractTempRefactoring.class;
							Constructor<ExtractTempRefactoring> ctor = cls.getDeclaredConstructor(
									org.eclipse.jdt.core.ICompilationUnit.class, int.class, int.class);
							ctor.setAccessible(true);
							refactoring = ctor.newInstance(cu, exprOffset, exprLen);
//	                      newVar = generateNewVariableName(targetMethod, cu);
							newVar = "i";
							refactoring.setTempName(newVar);
							item.newVariableName = newVar;
						} catch (Exception e) {
							item.message = "反射构造ExtractTempRefactoring失败:" + e.getMessage();
							e.printStackTrace();
							allRefactoringRecords.add(item);
							continue;
						}

						IProgressMonitor monitor = new NullProgressMonitor();
						RefactoringStatus statusInitial = refactoring.checkInitialConditions(monitor);
						if (statusInitial.hasError() || statusInitial.hasWarning()) {
							String msg = statusInitial.getMessageMatchingSeverity(RefactoringStatus.ERROR);
							if (msg == null) {
								msg = statusInitial.getMessageMatchingSeverity(RefactoringStatus.WARNING);
							}
							item.message = "前置校验存在错误/警告，不执行重构：" + msg;
							System.err.println("提取变量前置校验冲突：" + msg);
							allRefactoringRecords.add(item);
							continue;
						}
						RefactoringStatus statusFinal = refactoring.checkFinalConditions(monitor);
						if (statusFinal.hasError() || statusFinal.hasWarning()) {
							String msg = statusFinal.getMessageMatchingSeverity(RefactoringStatus.ERROR);
							if (msg == null) {
								msg = statusFinal.getMessageMatchingSeverity(RefactoringStatus.WARNING);
							}
							item.message = "最终校验存在错误/警告，不执行重构：" + msg;
							System.err.println("提取变量最终校验冲突：" + msg);
							allRefactoringRecords.add(item);
							continue;
						}

						try {
							PerformRefactoringOperation op = new PerformRefactoringOperation(refactoring, 3);
							JavaCore.run(op, monitor);
							item.success = true;
							item.message = "extract variable successfully.";
							System.out.println("提取变量重构执行成功");
						} catch (CoreException e) {
							item.message = "提取变量重构异常:" + e.getMessage();
							e.printStackTrace();
							System.err.println("提取变量重构异常");
						}
						allRefactoringRecords.add(item);
					}
				}
			}
			String jsonResult = JSON.toJSONString(allRefactoringRecords);
			String projectPath = javaProject.getResource().getLocation().toOSString();
			String outputFile = projectPath + java.io.File.separator + "refactor_result_extract_variable.json";
			try (java.io.FileWriter writer = new java.io.FileWriter(outputFile)) {
				writer.write(jsonResult);
				writer.flush();
				System.out.println("==== 提取变量重构结果已保存到 " + outputFile + "====");
			} catch (java.io.IOException ioEx) {
				ioEx.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static boolean extractedEclipseApproach(CompilationUnit compilationUnit, int offset, int length,
			String newName) {
		EclipseExtractTempRefactoring extractTempRefactoring = new EclipseExtractTempRefactoring(compilationUnit,
				offset, length);
		extractTempRefactoring.setTempName(newName);

		try {
			Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();

			RefactoringExecutionHelper helper = new RefactoringExecutionHelper(extractTempRefactoring,
					RefactoringCore.getConditionCheckingFailedSeverity(), RefactoringSaveHelper.SAVE_NOTHING, shell,
					PlatformUI.getWorkbench().getActiveWorkbenchWindow());
			helper.perform(true, true);
		} catch (Exception e) {
			e.printStackTrace();
			extractList = extractTempRefactoring.replaceList;
			return extractTempRefactoring.checkCondition;
		}
		extractList = extractTempRefactoring.replaceList;
		return extractTempRefactoring.checkCondition;
	}

	private static Expression extractExpressionsFromIMethod(CompilationUnit astRoot, String methodName,
			List<String> parameterTypes, String expression) throws JavaModelException {
//		System.out.println("expression:" + expression + "--" + parameterTypes);
		List<MethodDeclaration> methodDeclarations = getMethodDeclaration(astRoot);
		for (int i = 0; i < methodDeclarations.size(); i++) {
			MethodDeclaration methodDeclaration = methodDeclarations.get(i);
			String currentMethodName = methodDeclaration.getName().toString();
			List<SingleVariableDeclaration> parameters = methodDeclaration.parameters();
			List<String> currentParaTypes = new ArrayList<>();
			if (parameterTypes != null) {
				for (int a = 0; a < parameters.size(); a++) {
					currentParaTypes.add(parameters.get(a).getType().toString());
				}
			}
//			System.out.println("currentParaTypes:"+currentParaTypes);
			if (currentMethodName.equals(methodName) && parameterTypes.equals(currentParaTypes)) {
				if (methodDeclaration != null) {
					List<Expression> modifierExp = new ArrayList<>();
					methodDeclaration.accept(new ASTVisitor() {
						@Override
						public boolean visit(ExpressionStatement expressionStatement) {
//	                        System.out.println("Expression: " + expressionStatement.getExpression());
							if (expressionStatement.getExpression().toString().equals(expression)) {
								modifierExp.add(expressionStatement.getExpression());
								return true;
							}
							return false;
						}
					});

					if (modifierExp.size() > 0) {
						return modifierExp.get(0);
					} else {
						return null;
					}
				}
			}
		}
		return null;
	}

	public static List<MethodDeclaration> getMethodDeclaration(ASTNode cuu) {
		List<MethodDeclaration> methodDeclarations = new ArrayList<>();
		cuu.accept(new ASTVisitor() {
			@SuppressWarnings("unchecked")
			public boolean visit(MethodDeclaration node) {
				methodDeclarations.add(node);
				return true;
			}
		});
		return methodDeclarations;
	}

	public static List<ICompilationUnit> getAllCompilationUnits(IJavaProject javaProject) throws JavaModelException {
		List<ICompilationUnit> units = new ArrayList<>();
		IPackageFragmentRoot[] roots = javaProject.getPackageFragmentRoots();
		for (IPackageFragmentRoot root : roots) {
			// 判断是否为源码目录，排除jar包等库
			if (root.getKind() == IPackageFragmentRoot.K_SOURCE) {
				// 获取root下所有子元素（包）
				IJavaElement[] children = root.getChildren();
				for (IJavaElement child : children) {
					if (child instanceof IPackageFragment) {
						IPackageFragment pkg = (IPackageFragment) child;
						ICompilationUnit[] cus = pkg.getCompilationUnits();
						units.addAll(List.of(cus));
					}
				}
			}
		}
		return units;
	}

	private static String generateNewVariableName(IMethod targetMethod, ICompilationUnit cu) throws CoreException {
		List<Integer> strategyList = Arrays.asList(0, 1, 2, 3);
		int selectedStrategy = strategyList.get(new Random().nextInt(strategyList.size()));

		String newName;
		switch (selectedStrategy) {
		case 0:
			// 策略1：随机生成合法变量名
			newName = generateRandomIdentifier();
			break;
		case 1:
			// 策略2：取当前类字段名
			IType type = targetMethod.getDeclaringType();
			IField[] fields = type.getFields();
			List<String> fieldNames = new ArrayList<>();
			for (IField f : fields) {
				String fname = f.getElementName();
				fieldNames.add(fname);

			}
			if (!fieldNames.isEmpty()) {
				newName = fieldNames.get(new Random().nextInt(fieldNames.size()));
			} else {
				newName = generateRandomIdentifier();
			}
			break;
		case 2:
			// 策略3：方法内局部变量（AST解析获取，不再调用 getLocalVariables()）
			Set<String> localVarNameSet = collectMethodLocalVariables(targetMethod);
			List<String> localVarNames = new ArrayList<>();
			for (String lvName : localVarNameSet) {
				localVarNames.add(lvName);

			}
			if (!localVarNames.isEmpty()) {
				newName = localVarNames.get(new Random().nextInt(localVarNames.size()));
			} else {
				newName = generateRandomIdentifier();
			}
			break;
		case 3:
			// 策略4：取当前方法参数名
			ILocalVariable[] params = targetMethod.getParameters();
			List<String> paramNames = new ArrayList<>();
			for (ILocalVariable p : params) {
				String pname = p.getElementName();
				paramNames.add(pname);
			}
			if (!paramNames.isEmpty()) {
				newName = paramNames.get(new Random().nextInt(paramNames.size()));
			} else {
				newName = generateRandomIdentifier();
			}
			break;
		default:
			newName = generateRandomIdentifier();
		}
		return newName;
	}

	private static Set<String> collectMethodLocalVariables(IMethod method) throws CoreException {
		Set<String> localVarNames = new HashSet<>();
		ICompilationUnit cu = method.getCompilationUnit();
		if (cu == null) {
			return localVarNames;
		}

		// 创建AST，解析编译单元
		ASTParser parser = ASTParser.newParser(AST.JLS17);
		parser.setSource(cu);
		parser.setResolveBindings(true);
		parser.setBindingsRecovery(true);
		CompilationUnit astRoot = (CompilationUnit) parser.createAST(null);

		// 定位到当前IMethod对应的AST MethodDeclaration节点
		MethodDeclarationVisitor visitor = new MethodDeclarationVisitor(method);
		astRoot.accept(visitor);
		MethodDeclaration methodAst = visitor.getMatchedMethod();
		if (methodAst == null) {
			return localVarNames;
		}

		// 遍历方法体，收集局部变量
		methodAst.accept(new ASTVisitor() {
			@Override
			public boolean visit(VariableDeclarationFragment node) {
				// VariableDeclarationFragment 包含局部变量、字段；
				// 判断父节点是否是 VariableDeclarationStatement，只有这个才是【方法体内局部变量】
				if (node.getParent() instanceof VariableDeclarationStatement) {
					String varName = node.getName().getIdentifier();
					localVarNames.add(varName);
				}
				return true;
			}
		});
		return localVarNames;
	}

	private static String generateRandomIdentifier() {
		Random random = new Random();
		// 首字符必须是字母
		char first = (char) ('a' + random.nextInt(26));
		StringBuilder sb = new StringBuilder();
		sb.append(first);
		// 后面追加 3~6 个字母数字
		int len = 3 + random.nextInt(4);
		for (int i = 0; i < len; i++) {
			if (random.nextBoolean()) {
				sb.append((char) ('a' + random.nextInt(26)));
			} else {
				sb.append(random.nextInt(10));
			}
		}
		return sb.toString();
	}

}
