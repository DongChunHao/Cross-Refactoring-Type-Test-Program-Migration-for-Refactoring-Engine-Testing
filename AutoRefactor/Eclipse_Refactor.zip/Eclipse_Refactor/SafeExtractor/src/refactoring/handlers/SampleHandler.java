package refactoring.handlers;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.OperationCanceledException;

import refactoring.Info.RenameElemInfo;
import refactoring.Info.RenameMethodInfo;

public class SampleHandler extends AbstractHandler {
	public static long start;
	public static int end;
	public static final boolean DESCRIPTOR_TEST = false;
	public boolean fIsPreDeltaTest = false;
	static List<String> projectList = new ArrayList<>();
	static List<RenameElemInfo> parameterInfos = new ArrayList<>();
	static List<RenameElemInfo> localVariableInfos = new ArrayList<>();
	static List<RenameElemInfo> fieldInfos = new ArrayList<>();
	static List<RenameMethodInfo> methodInfos = new ArrayList<>();
	static List<RenameElemInfo> classInfos = new ArrayList<>();
	static List<IFile> javaFiles = new ArrayList<>();
	protected static final String TEST_OUTPUT_INFIX = "D:\\eclipse\\workspace\\Dataset\\";

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {

		try {
			// 测试 Rename variable
//			RenameVariableHandler renameVar = new RenameVariableHandler();
//			renameVar.handlerLocalVariableRenameRefactoring(event);

			// 测试 Rename field
//			RenameFieldHandler renameField = new RenameFieldHandler();
//			renameField.handlerFieldRenameRefactoring(event);

			// 测试 Rename method
//			RenameMethodHandler renameMethod = new RenameMethodHandler();
//			renameMethod.handlerMethodRenameRefactoring(event);

			// 测试 Move
//			MoveMethodHandler moveMethod = new MoveMethodHandler();
//			moveMethod.handlerMoveMethod(event);

			// 测试inline
//			InlineMethodHandler inlineMethod = new InlineMethodHandler();
//			inlineMethod.handlerInlineMethod(event);

			// 测试extract variable
			ExtractVariableHandler extractVar = new ExtractVariableHandler();
			extractVar.handlerExtractVariable(event);

			// 测试 extract method
//			ExtractMethodHanlder extractMethod = new ExtractMethodHanlder();
//			extractMethod.handlerExtractMethod(event);
		} catch (OperationCanceledException e) {
			e.printStackTrace();
		}
		return null;
	}
}
