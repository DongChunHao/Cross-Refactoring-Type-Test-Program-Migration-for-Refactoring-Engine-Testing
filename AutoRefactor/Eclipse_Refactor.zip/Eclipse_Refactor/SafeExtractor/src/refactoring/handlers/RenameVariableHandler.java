package refactoring.handlers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IField;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.ILocalVariable;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IPackageDeclaration;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.ISourceRange;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.IVariableBinding;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;
import org.eclipse.jdt.internal.corext.refactoring.ParameterInfo;
import org.eclipse.jdt.internal.corext.refactoring.rename.RenameLocalVariableProcessor;
import org.eclipse.ltk.core.refactoring.Change;
import org.eclipse.ltk.core.refactoring.Refactoring;
import org.eclipse.ltk.core.refactoring.RefactoringStatus;
import org.eclipse.ltk.core.refactoring.participants.ProcessorBasedRefactoring;

import com.alibaba.fastjson.JSON;

import refactoring.Info.RenameElemInfo;
import refactoring.Info.RenameMethodInfo;
import refactoring.Info.RenameVariableInfo;
import refactoring.file.parse.GetProject;
import refactoring.random.type.PerformRefactoring;

public class RenameVariableHandler {
	public static long start;
	public static int end;
	public static final boolean DESCRIPTOR_TEST = false;
	public boolean fIsPreDeltaTest = false;
	static List<String> projectList = new ArrayList<>();
	static List<RenameElemInfo> parameterInfos = new ArrayList<>();
	static List<RenameElemInfo> localVariableInfos = new ArrayList<>();
	static List<RenameElemInfo> fieldInfos = new ArrayList<>();
	static List<RenameMethodInfo> methodInfos = new ArrayList<>();
	static List<RenameElemInfo> classInfos = new ArrayList<>();
	static List<IFile> javaFiles = new ArrayList<>();
	protected static final String TEST_OUTPUT_INFIX = "D:\\eclipse\\workspace\\Dataset\\";

	static void handlerLocalVariableRenameRefactoring(ExecutionEvent event) {
		String refactoringProjectName = "TEST";
		IJavaProject javaProject;
		List<RenameVariableInfo> allRefactoringRecords = new ArrayList<>();
		String targetMethodName = "refMethod";

		try {
			javaProject = GetProject.getJavaProject(refactoringProjectName);
			List<ICompilationUnit> cuList = getAllCompilationUnits(javaProject);

			for (ICompilationUnit cu : cuList) {
				if (cu.hasUnsavedChanges()) {
					cu.save(new NullProgressMonitor(), true);
				}
				String cuFilePath = cu.getResource().getFullPath().toString();
				String packageName = "";
				IPackageDeclaration[] pkgDecls = cu.getPackageDeclarations();
				if (pkgDecls != null && pkgDecls.length > 0) {
					packageName = pkgDecls[0].getElementName();
				}
				IType[] allTypes = cu.getAllTypes();

				for (IType type : allTypes) {
					String className = type.getElementName();
					for (IMethod targetMethod : type.getMethods()) {
						if (targetMethodName.equals(targetMethod.getElementName())) {
							List<ILocalVariable> localVarsInMethod = getMethodBodyLocalVariables(targetMethod);
							for (ILocalVariable localVar : localVarsInMethod) {
								String oldName = localVar.getElementName();
								if (!oldName.equals("variableToBeRenamed")) {
									continue;
								}
								RenameVariableInfo item = new RenameVariableInfo();
								item.packageName = packageName;
								item.className = className;
								item.methodName = targetMethod.getElementName();
								item.oldVarName = oldName;
								item.sourceFilePath = cuFilePath;
								item.success = false;
								item.message = "";
								try {
									ISourceRange range = localVar.getSourceRange();
									item.offset = range.getOffset();
									item.length = range.getLength();
								} catch (CoreException e) {
									item.offset = -1;
									item.length = -1;
									item.message += "获取源码位置失败:" + e.getMessage() + ";";
								}

								String newName = null;
								try {
									newName = generateNewVariableName(targetMethod, cu, localVar);
									item.newVarName = newName;
									System.out.println("生成新变量名：" + newName);
								} catch (Exception e) {
									item.message = "生成新变量名失败: " + e.getMessage();
									allRefactoringRecords.add(item);
									e.printStackTrace();
									continue;
								}

								RenameLocalVariableProcessor processor = new RenameLocalVariableProcessor(localVar);
								processor.setNewElementName(newName);
								Refactoring refactoring = new ProcessorBasedRefactoring(processor);
								IProgressMonitor monitor = new NullProgressMonitor();

								try {
									RefactoringStatus status = refactoring.checkAllConditions(monitor);
									System.out.println("===== RefactoringStatus 完整信息：" + status.toString());
									if (status.hasError() || status.hasWarning()) {
										String msg = status.getMessageMatchingSeverity(RefactoringStatus.ERROR);
										if (msg == null) {
											msg = status.getMessageMatchingSeverity(RefactoringStatus.WARNING);
										}
										item.message = "重构校验存在错误/警告，不执行重构：" + msg;
										System.err.println("文件:" + cuFilePath + " 局部变量重构校验冲突：" + msg);
									} else {
										Change change = refactoring.createChange(monitor);
										change.perform(monitor);
										item.success = true;
										item.message = "variable renamed successfully.";
										System.out.println("文件:" + cuFilePath + " variable renamed successfully.");
										PerformRefactoring.no += 1;
									}
								} catch (CoreException e) {
									item.message = "重构执行异常: " + e.getMessage();
									System.err.println("文件:" + cuFilePath + " 局部变量重构失败: " + e.getMessage());
									e.printStackTrace();
								}
								allRefactoringRecords.add(item);
								break;
							}
						}
					}
				}
			}

			String jsonResult = JSON.toJSONString(allRefactoringRecords);
			String projectPath = javaProject.getResource().getLocation().toOSString();
			String outputFile = projectPath + java.io.File.separator + "refactor_result_rename_var.json";
			try (java.io.FileWriter writer = new java.io.FileWriter(outputFile)) {
				writer.write(jsonResult);
				writer.flush();
				System.out.println("====所有Java文件重构结果已全部保存到 refactor_result_rename_var.json====");
			} catch (java.io.IOException ioEx) {
				ioEx.printStackTrace();
			}

		} catch (CoreException e1) {
			e1.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void modifyInfos(List<ParameterInfo> list, String[] newNames) {
		int i = 0;
		for (Iterator<ParameterInfo> iter = list.iterator(); iter.hasNext(); i++) {
			ParameterInfo info = iter.next();
			info.setNewName(newNames[i]);
		}
	}

	private static List<ILocalVariable> getMethodBodyLocalVariables(IMethod method) throws CoreException {
		List<ILocalVariable> localVarList = new ArrayList<>();
		ICompilationUnit cu = method.getCompilationUnit();
		if (cu == null)
			return localVarList;

		ASTParser parser = ASTParser.newParser(AST.JLS17);
		parser.setSource(cu);
		parser.setResolveBindings(true);
		parser.setBindingsRecovery(true);
		CompilationUnit astRoot = (CompilationUnit) parser.createAST(null);

		// 找到对应IMethod的AST MethodDeclaration
		astRoot.accept(new ASTVisitor() {
			@Override
			public boolean visit(MethodDeclaration methodAst) {
				IMethod bindMethod = (IMethod) methodAst.resolveBinding().getJavaElement();
				if (!method.equals(bindMethod)) {
					return true;
				}
				// 找到目标方法，遍历方法体内变量
				methodAst.accept(new ASTVisitor() {
					@Override
					public boolean visit(VariableDeclarationFragment fragment) {
						// 父节点是VariableDeclarationStatement：方法{}内定义的局部变量
						if (fragment.getParent() instanceof VariableDeclarationStatement) {
							IVariableBinding binding = fragment.resolveBinding();
							if (binding == null)
								return true;
							IJavaElement ele = binding.getJavaElement();
							if (ele instanceof ILocalVariable localVar) {
								localVarList.add(localVar);
							}
						}
						return true;
					}
				});
				return false;
			}
		});
		return localVarList;
	}

	private static String generateNewVariableName(IMethod targetMethod, ICompilationUnit cu, ILocalVariable oldVar)
			throws CoreException {
		List<Integer> strategyList = Arrays.asList(0, 1, 2, 3);
		int selectedStrategy = strategyList.get(new Random().nextInt(strategyList.size()));
		String oldName = oldVar.getElementName();

		String newName;
		switch (selectedStrategy) {
		case 0:
			// 策略1：随机生成合法变量名
			newName = generateRandomIdentifier();
			break;
		case 1:
			// 策略2：取当前类字段名
			IType type = targetMethod.getDeclaringType();
			IField[] fields = type.getFields();
			List<String> fieldNames = new ArrayList<>();
			for (IField f : fields) {
				String fname = f.getElementName();
				if (!fname.equals(oldName)) {
					fieldNames.add(fname);
				}
			}
			if (!fieldNames.isEmpty()) {
				newName = fieldNames.get(new Random().nextInt(fieldNames.size()));
			} else {
				newName = generateRandomIdentifier();
			}
			break;
		case 2:
			// 策略3：方法内局部变量（AST解析获取，不再调用 getLocalVariables()）
			Set<String> localVarNameSet = collectMethodLocalVariables(targetMethod);
			List<String> localVarNames = new ArrayList<>();
			for (String lvName : localVarNameSet) {
				if (!lvName.equals(oldName)) {
					localVarNames.add(lvName);
				}
			}
			if (!localVarNames.isEmpty()) {
				newName = localVarNames.get(new Random().nextInt(localVarNames.size()));
			} else {
				newName = generateRandomIdentifier();
			}
			break;
		case 3:
			// 策略4：取当前方法参数名
			ILocalVariable[] params = targetMethod.getParameters();
			List<String> paramNames = new ArrayList<>();
			for (ILocalVariable p : params) {
				String pname = p.getElementName();
				if (!pname.equals(oldName)) {
					paramNames.add(pname);
				}
			}
			if (!paramNames.isEmpty()) {
				newName = paramNames.get(new Random().nextInt(paramNames.size()));
			} else {
				newName = generateRandomIdentifier();
			}
			break;
		default:
			newName = generateRandomIdentifier();
		}
		return newName;
	}

	/**
	 * 生成合法Java标识符（小写开头字母+数字）
	 * 
	 * @return 随机变量名
	 */
	private static String generateRandomIdentifier() {
		Random random = new Random();
		// 首字符必须是字母
		char first = (char) ('a' + random.nextInt(26));
		StringBuilder sb = new StringBuilder();
		sb.append(first);
		// 后面追加 3~6 个字母数字
		int len = 3 + random.nextInt(4);
		for (int i = 0; i < len; i++) {
			if (random.nextBoolean()) {
				sb.append((char) ('a' + random.nextInt(26)));
			} else {
				sb.append(random.nextInt(10));
			}
		}
		return sb.toString();
	}

	private static Set<String> collectMethodLocalVariables(IMethod method) throws CoreException {
		Set<String> localVarNames = new HashSet<>();
		ICompilationUnit cu = method.getCompilationUnit();
		if (cu == null) {
			return localVarNames;
		}

		// 创建AST，解析编译单元
		ASTParser parser = ASTParser.newParser(AST.JLS17);
		parser.setSource(cu);
		parser.setResolveBindings(true);
		parser.setBindingsRecovery(true);
		CompilationUnit astRoot = (CompilationUnit) parser.createAST(null);

		// 定位到当前IMethod对应的AST MethodDeclaration节点
		MethodDeclarationVisitor visitor = new MethodDeclarationVisitor(method);
		astRoot.accept(visitor);
		MethodDeclaration methodAst = visitor.getMatchedMethod();
		if (methodAst == null) {
			return localVarNames;
		}

		// 遍历方法体，收集局部变量
		methodAst.accept(new ASTVisitor() {
			@Override
			public boolean visit(VariableDeclarationFragment node) {
				// VariableDeclarationFragment 包含局部变量、字段；
				// 判断父节点是否是 VariableDeclarationStatement，只有这个才是【方法体内局部变量】
				if (node.getParent() instanceof VariableDeclarationStatement) {
					String varName = node.getName().getIdentifier();
					localVarNames.add(varName);
				}
				return true;
			}
		});
		return localVarNames;
	}

	/**
	 * AST Visitor：找到与IMethod匹配的MethodDeclaration
	 */
	static class MethodDeclarationVisitor extends ASTVisitor {
		private final IMethod targetIMethod;
		private MethodDeclaration matchedMethod;

		public MethodDeclarationVisitor(IMethod targetIMethod) {
			this.targetIMethod = targetIMethod;
		}

		@Override
		public boolean visit(MethodDeclaration node) {
			IMethod bindingMethod = (IMethod) node.resolveBinding().getJavaElement();
			if (targetIMethod.equals(bindingMethod)) {
				matchedMethod = node;
				return false; // 找到就不再继续遍历
			}
			return true;
		}

		public MethodDeclaration getMatchedMethod() {
			return matchedMethod;
		}
	}

	// 遍历IJavaProject下所有ICompilationUnit
	public static List<ICompilationUnit> getAllCompilationUnits(IJavaProject javaProject) throws JavaModelException {
		List<ICompilationUnit> units = new ArrayList<>();
		IPackageFragmentRoot[] roots = javaProject.getPackageFragmentRoots();
		for (IPackageFragmentRoot root : roots) {
			// 判断是否为源码目录，排除jar包等库
			if (root.getKind() == IPackageFragmentRoot.K_SOURCE) {
				// 获取root下所有子元素（包）
				IJavaElement[] children = root.getChildren();
				for (IJavaElement child : children) {
					if (child instanceof IPackageFragment) {
						IPackageFragment pkg = (IPackageFragment) child;
						ICompilationUnit[] cus = pkg.getCompilationUnits();
						units.addAll(List.of(cus));
					}
				}
			}
		}
		return units;
	}

}
